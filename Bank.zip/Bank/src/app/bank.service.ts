import { Injectable } from '@angular/core';
import {Observable} from 'rxjs'
import {HttpClient} from '@angular/common/http';
import { IBank } from './ibank';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  constructor(private http:HttpClient) { }
  private _url="./assets/bankdetails.json";
  getBank():Observable<IBank[]>{
    return this.http.get<IBank[]>(this._url);
  } 
}
