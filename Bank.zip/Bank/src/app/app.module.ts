import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule,routingcomponents } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { MainDetailsComponent } from './main-details/main-details.component'
@NgModule({
  declarations: [
    AppComponent,
   routingcomponents,
   ShowBalanceComponent,
   MainDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
