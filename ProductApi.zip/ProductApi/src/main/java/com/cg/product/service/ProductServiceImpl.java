package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productDao;
	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}
	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productDao.findById(id).get();
	}
	@Override
	public void updateProduct(Product pro) {
		productDao.save(pro);
		
	}
	@Override
	public void addProduct(Product pro) {
		productDao.save(pro);
		
	}
	@Override
	public void deleteProduct(int id) {
		productDao.deleteById(id);
		
	}
	@Override
	public List<Product> getProductByCatagory(String catagory) {
		// TODO Auto-generated method stub
		return productDao.getProductByCatagory(catagory);
	}
	@Override
	public List<Product> getProductByPrice(double minprice, double maxprice) {
		// TODO Auto-generated method stub
		return productDao.getProductByPrice(minprice, maxprice);
	}

	
}
