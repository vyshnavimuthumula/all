package com.cg.product.service;

import java.util.List;

import com.cg.product.bean.Product;


public interface ProductService {

	List<Product> getAllProducts();
	Product getProductById(int id);
	List<Product> getProductByCatagory(String catagory);
	void updateProduct(Product pro);
	void addProduct(Product pro);
	void deleteProduct(int id);
	List<Product> getProductByPrice(double minprice,double maxprice);
	
}
