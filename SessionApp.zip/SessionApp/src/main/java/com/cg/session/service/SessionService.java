package com.cg.session.service;

import java.util.List;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;

public interface SessionService {

	List<Session> getAllSessions() throws SessionException;
	List<Session> addSession(Session session) throws SessionException;
	void deleteSession(Integer id) throws SessionException;	
	List<Session> updateDuration(Integer id,Session duration) throws SessionException;	
	List<Session> updateFaculty(Integer id,Session faculty) throws SessionException;
}
