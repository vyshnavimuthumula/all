package com.cg.product.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.product.bean.Product;


public interface ProductDao extends JpaRepository<Product, Integer>{

	@Query("from Product where catagory=:cat")
	List<Product> getProductByCatagory(@Param("cat") String catagory);
	
	@Query("from Product where price BETWEEN :minprice and :maxprice")
	List<Product> getProductByPrice(@Param("minprice") double minprice,@Param("maxprice") double maxprice);

}
