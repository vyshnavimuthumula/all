import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-user',
  templateUrl: './existing-user.component.html',
  styleUrls: ['./existing-user.component.css']
})
export class ExistingUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
