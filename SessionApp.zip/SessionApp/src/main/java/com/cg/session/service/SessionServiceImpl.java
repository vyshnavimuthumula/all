package com.cg.session.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDao;
import com.cg.session.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService{
	
	@Autowired
	SessionDao sessionDao;

	@Override
	public List<Session> getAllSessions() throws SessionException{
		try {
			return sessionDao.findAll();
		}catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
	}

	@Override
	public List<Session> addSession(Session session) throws SessionException{
		try {
			if(session.getDuration()<=3 && (session.getMode().equalsIgnoreCase("ilt") || session.getMode().equalsIgnoreCase("vc"))) {
				sessionDao.save(session);
			return sessionDao.findAll();
			}
			else {
				throw new SessionException("invalid session ");
			}
		}catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
	}

	@Override
	public void deleteSession(Integer id) throws SessionException{
		try {
			sessionDao.deleteById(id);
		}catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
		
	}

	@Override
	public List<Session> updateDuration(Integer id, Session session) throws SessionException{
		try {
			Optional<Session> optional=sessionDao.findById(id);
			if(optional.isPresent() && session.getDuration()<=3 && (session.getMode().equalsIgnoreCase("ilt") || session.getMode().equalsIgnoreCase("vc"))) {
				Session sessions=optional.get();
				sessions.setDuration(session.getDuration());
				sessionDao.save(sessions);
				return getAllSessions();
			}
			else
			{
				throw new SessionException("Customer with id " + id + " does not exit");
			}
		}catch(Exception e) {
				throw new SessionException(e.getMessage());
		}
		
	}

	@Override
	public List<Session> updateFaculty(Integer id, Session session) throws SessionException{
		try {
			Optional<Session> optional=sessionDao.findById(id);
			if(optional.isPresent() && session.getDuration()<=3 && (session.getMode().equalsIgnoreCase("ilt") || session.getMode().equalsIgnoreCase("vc"))) {
			Session sessions=optional.get();
			sessions.setFaculty(session.getFaculty());
			sessionDao.save(sessions);
			return getAllSessions();
		}
		else
		{
			throw new SessionException("Customer with id " + id + " does not exit");
		}
	}catch(Exception e) {
			throw new SessionException(e.getMessage());
	}
	}

}
