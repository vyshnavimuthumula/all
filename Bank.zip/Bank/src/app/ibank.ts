export interface IBank {
    "accountnum" : number,
    "pin":number
}
