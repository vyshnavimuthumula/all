import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewUserComponent } from './new-user/new-user.component';
import { ExistingUserComponent } from './existing-user/existing-user.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { MainDetailsComponent } from './main-details/main-details.component';
export const routingcomponents = [NewUserComponent,ExistingUserComponent,CreateAccountComponent,ShowBalanceComponent,MainDetailsComponent]

const routes: Routes = [
  {
    path: 'newuser',
    component:NewUserComponent
  },
  {
    path: 'login',
    component: ExistingUserComponent
  },
  {
    path: 'createaccount',
    component :CreateAccountComponent
  },
  {
    path:'showbalance',
    component : ShowBalanceComponent
  },
  {
    path :'maindetails',
    component : MainDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
