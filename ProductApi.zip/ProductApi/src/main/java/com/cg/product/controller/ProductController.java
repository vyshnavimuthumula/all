package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.bean.Product;
import com.cg.product.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/api/products")
	public List<Product> getProduct(){
		return productService.getAllProducts();
		
	}
	@GetMapping("/api/products/{id}")
	public Product getProduct(@PathVariable int id){
		return productService.getProductById(id);
		
	}
	
	@PostMapping("/api/products")
	public ResponseEntity<String> addProduct(@RequestBody Product pro){
		productService.addProduct(pro);
		return new ResponseEntity<String>("product successfully added",HttpStatus.OK);
	}
	
	@RequestMapping(value="/api/products",method=RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(@RequestBody Product pro){
		productService.updateProduct(pro);
		return new ResponseEntity<String>("Product successfully updated",HttpStatus.OK);
	}
	
	@RequestMapping(value="/api/products/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable int id){
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Product with the id "+ id + "deleted",HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/api/products/catagory")
	public List<Product> getProduct(@RequestParam String catagory) {
		return productService.getProductByCatagory(catagory);
	}
	
	@RequestMapping(value="/api/products/price")
	public List<Product> getProduct(@RequestParam double minprice,double maxprice){
		return productService.getProductByPrice(minprice, maxprice);
	}
}
