import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-details',
  templateUrl: './main-details.component.html',
  styleUrls: ['./main-details.component.css']
})
export class MainDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
