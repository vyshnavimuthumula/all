import { Component, OnInit } from '@angular/core';
import { IBank } from '../ibank';
import {BankService} from 'src/app/bank.service'
@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  constructor(private bankDetailsservice:BankService) { }
  bankDetails:IBank[];
  BankService :any;
  ngOnInit() {
    this.bankDetailsservice.getBank().subscribe(data=>this.bankDetails=data);
  }

}
