package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionService;

@RestController
public class SessionContoller {

	@Autowired
	SessionService sessionService;
	
	@RequestMapping("/session")
	public List<Session> getSessions() throws SessionException{
		return sessionService.getAllSessions();
		
	}
//	@RequestMapping("/session/{id}")
//	public List<Session> getSessionById(int id){
//		return sessionService.getSessionById();
//		
//	}
	
	@RequestMapping(value="/session/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteSession(@PathVariable int id) throws SessionException{
		sessionService.deleteSession(id);
		return new ResponseEntity<String>("Session with id " + id +"deleted",HttpStatus.OK);
	}
	@RequestMapping(value="/session",method=RequestMethod.POST)
	public List<Session> addSession(@RequestBody Session sess) throws SessionException{
		return sessionService.addSession(sess);
	}
	@RequestMapping(value="/updatesessionduration/{id}",method=RequestMethod.PUT)
	public List<Session> updateDuration(@PathVariable Integer id,@RequestBody Session duration) throws SessionException{
		return sessionService.updateDuration(id, duration);
	}
	
	@RequestMapping(value="/updatesessionfaculty/{id}",method=RequestMethod.PUT)
	public List<Session> updateFaculty(@PathVariable Integer id,@RequestBody Session faculty) throws SessionException{
		return sessionService.updateFaculty(id, faculty);
	}
}
