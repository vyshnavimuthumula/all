package com.cg.session.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="sess")

public class Session implements Serializable{

	@Id
	@GeneratedValue
	private int id;
	private String name;
	private String faculty;
	@Column(name="mode1")
	private String mode;
	private int duration;
	@Override
	public String toString() {
		return "Session [id=" + id + ", name=" + name + ", faculty=" + faculty + ", mode=" + mode + ", duration="
				+ duration + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
